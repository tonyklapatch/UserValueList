userValueList is a snippet that can keep track of data across your website. When a user is logged in you can let him keep a wishlist for products for instance.

Usage:

Just place the [[!addToUserValues]] snippet on your memberpages and read the value with [[!getUserValues]]